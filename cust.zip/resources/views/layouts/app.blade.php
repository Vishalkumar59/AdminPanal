<!DOCTYPE html>

<html lang="en">
  @include('common.head') 

  <body >

      
      <main>
        
             @yield('content')
      </main>

      @include('common.footer')
                    
            
      @stack('scripts')

      @include('common.scripts')
        
               
  </body>
</html>