 <!-- ======= Header ======= -->
 <header id="header" class="header-top">
    <div class="container">

      <h1><a href="{{route('dashboard')}}">Vishal Kumar ...</a></h1>
      <!-- Uncomment below if you prefer to use an image logo -->
      <!-- <a href="index.html" class="mr-auto"><img src="assets/img/logo.png" alt="" class="img-fluid"></a> -->
      <h2>I'm a passionate <span>graphic designer</span> from New York</h2>

      <nav id="navbar" class="navbar">
        <ul>
          <li><a class="nav-link " href="{{route('home')}}">Home</a></li>
          <li><a class="nav-link" href="{{route('about')}}">About</a></li>
          <li><a class="nav-link" href="{{route('resume')}}">Resume</a></li>
          <li><a class="nav-link" href="{{route('services')}}">Services</a></li>
          <li><a class="nav-link" href="{{route('portfolio')}}">Portfolio</a></li>
          <li><a class="nav-link" href="{{route('contact')}}">Contact</a></li>
          <li><a class="nav-link" href="{{route('signout')}}">Log Out</a></li>
        </ul>
        <i class="bi bi-list mobile-nav-toggle"></i>
      </nav><!-- .navbar -->

      <div class="social-links">
        <a href="#" class="twitter"><i class="bi bi-twitter"></i></a>
        <a href="#" class="facebook"><i class="bi bi-facebook"></i></a>
        <a href="#" class="instagram"><i class="bi bi-instagram"></i></a>
        <a href="#" class="linkedin"><i class="bi bi-linkedin"></i></a>
      </div>

    </div>
  
</header>