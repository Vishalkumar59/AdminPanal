<!DOCTYPE html>
<html>
<head>
<meta name="viewport" content="width=device-width, initial-scale=1">
<style>

body {
    background-color: #111116;
}

.center {
  position: absolute;
  left: 50%;
  top: 50%;
  transform: translateX(-50%) translateY(-50%);
}

.circle {
    display: inline-block;
    width: 32px;
    height: 32px;
    border-radius: 50%;
    margin: 0 4px;
}

.circle-1 {
    border: 4px solid red;
}

.circle-2 {
    border: 4px solid green;
}

.circle-3 {
    border:  4px solid blue;
}

.circle-4 {
    border:  4px solid yellow;
}


</style>
</head>
<body>
    <h2>hello</h2>
<div class='center'>
  <div class='loader'>
    <div class='circle circle-1'></div>
    <div class='circle circle-2'></div>
    <div class='circle circle-3'></div>
    <div class='circle circle-4'></div>
  </div>
</div>
<script src="https://code.jquery.com/jquery-3.6.3.min.js" integrity="sha256-pvPw+upLPUjgMXY0G+8O0xUf+/Im1MZjXxxgOcBQBXU=" crossorigin="anonymous"></script>
<script src="https://cdnjs.cloudflare.com/ajax/libs/animejs/3.2.1/anime.min.js"></script>

<script type="text/javascript">
$(document).ready(function(){

        var circle1 = anime({
          targets: ['.circle-1'],
          translateY: -24,
                translateX: 52,
                direction: 'alternate',
          loop: true,
          elasticity: 400,
                easing: 'easeInOutElastic',
             duration: 1600,
                delay: 800,
        });

        var circle2 = anime ({
          targets: ['.circle-2'],
          translateY: 24,
                direction: 'alternate',
          loop: true,
          elasticity: 400,
                easing: 'easeInOutElastic',
             duration: 1600,
                delay: 800,
        });

        var circle3 = anime ({
          targets: ['.circle-3'],
          translateY: -24,
                direction: 'alternate',
          loop: true,
          elasticity: 400,
                easing: 'easeInOutElastic',
             duration: 1600,
                delay: 800,
        });

        var circle4 = anime ({
          targets: ['.circle-4'],
          translateY: 24,
                translateX: -52,
                direction: 'alternate',
          loop: true,
          elasticity: 400,
                easing: 'easeInOutElastic',
             duration: 1600,
                delay: 800,
        });
});
</script>


</body>
</html>
