
@extends('layouts.app')
@section('content')
  <!-- ======= Header ======= -->
  <header id="header">
    <div class="container">

      <h1><a href="#">Vishal Kumar</a></h1>
      <!-- Uncomment below if you prefer to use an image logo -->
      <!-- <a href="index.html" class="mr-auto"><img src="assets/img/logo.png" alt="" class="img-fluid"></a> -->
      <h2>I'm a <span>Laravel Developer</span> from Varanasi</h2>

      <nav id="navbar" class="navbar">
        <ul>
          <li><a class="nav-link active" href="{{route('home')}}">Home</a></li>
          <li><a class="nav-link" href="#">TimePass</a></li>
          <li><a class="nav-link" href="{{route('about')}}">About</a></li>
          <li><a class="nav-link" href="{{route('resume')}}">Resume</a></li>
          <li><a class="nav-link" href="{{route('services')}}">Services</a></li>
          <li><a class="nav-link" href="{{route('portfolio')}}">Portfolio</a></li>
          <li><a class="nav-link" href="{{route('contact')}}">Contact</a></li>
          <li><a class="nav-link" href="{{route('signout')}}">Log Out</a></li>
        </ul>
        <i class="bi bi-list mobile-nav-toggle"></i>
      </nav><!-- .navbar -->

      <div class="social-links">
        <a href="https://twitter.com/" class="twitter"><i class="bi bi-twitter"></i></a>
        <a href="https://facebook.com" class="facebook"><i class="bi bi-facebook"></i></a>
        <a href="https://instagram.com/" class="instagram"><i class="bi bi-instagram"></i></a>
        <a href="https://in.linkedin.com" class="linkedin"><i class="bi bi-linkedin"></i></a>
      </div>

    </div>
  </header><!-- End Header -->
@endsection