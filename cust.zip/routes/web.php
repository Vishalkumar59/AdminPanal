<?php

use Illuminate\Support\Facades\Route;
use App\Http\Controllers\HelloController;
use App\Http\Controllers\QrCodeController;
use App\Http\Controllers\CustomAuthController;
use App\Http\Controllers\PortfolioController;
use App\Http\Controllers\UserController;
use App\Http\Controllers\SnakeController;
use App\Http\Controllers\LanguageController;
/*
|--------------------------------------------------------------------------
| Web Routes
|--------------------------------------------------------------------------
|
| Here is where you can register web routes for your application. These
| routes are loaded by the RouteServiceProvider within a group which
| contains the "web" middleware group. Now create something great!
|
*/

Route::get('/', function () {
    return view('auth.login');
});

Route::get('hello', [HelloController::class,'index']);
Route::get('qrcode', [QrCodeController::class,'run']);

Route::get('/dashboard', [CustomAuthController::class, 'dashboard'])->name('dashboard');
Route::get('login', [CustomAuthController::class, 'index'])->name('login');
Route::post('custom-login', [CustomAuthController::class, 'customLogin'])->name('login.custom'); 
Route::get('registration', [CustomAuthController::class, 'registration'])->name('register-user');
Route::post('/custom-registration', [CustomAuthController::class, 'customRegistration'])->name('register'); 
Route::get('signout', [CustomAuthController::class, 'signOut'])->name('signout');


//portfolio route
Route::get('home', [PortfolioController::class, 'home'])->name('home');
Route::get('about-us', [PortfolioController::class, 'about'])->name('about');
Route::get('resume', [PortfolioController::class, 'resume'])->name('resume');
Route::get('services', [PortfolioController::class, 'services'])->name('services');
Route::get('portfolio', [PortfolioController::class, 'portfolio'])->name('portfolio');
Route::get('contact', [PortfolioController::class, 'contact'])->name('contact');

//import & export routes
Route::get('/file-import-export', [UserController::class, 'fileImportExport'])->name('file-import-export');
Route::post('file-import', [UserController::class, 'fileImport'])->name('file-import');
Route::get('file-export', [UserController::class, 'fileExport'])->name('file-export');


//snake route
Route::get('index', [SnakeController::class, 'index'])->name('index');
Route::get('preloader', [SnakeController::class, 'preloader'])->name('preloader');

//language route
Route::get('lang', [LanguageController::class, 'index'])->name('lang');
Route::get('lang/change', [LanguageController::class, 'change'])->name('changeLanguage');