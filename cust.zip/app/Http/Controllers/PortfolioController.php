<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use Illuminate\Support\Facades\Auth;

class PortfolioController extends Controller
{
    public function home() 
    {
        if (Auth::check()) {

            return view('dashboard');
        
        } else {

            return redirect()->route('login')->with('You are not allowed to access');

        }

    }

    public function about() 
    {
        if (Auth::check()) {

            return view('about.about_us');

        } else {

            return redirect()->route('login')->with('You are not allowed to access');

        }
    }

    public function resume()
    {
        if (Auth::check()) {

           return view('resume.resume');

        } else {

            return redirect()->route('login')->with('You are not allowed to access');

        }
    }

    public function services()
    {
        if (Auth::check()) {

           return view('services.services');

        } else {

            return redirect()->route('login')->with('You are not allowed to access');

        }

    }

    public function portfolio()
    {
        if (Auth::check()) {

           return view('portfolio.portfolio');

        } else {

            return redirect()->route('login')->with('You are not allowed to access');

        }

    }

    public function contact()
    {
        if (Auth::check()) {

           return view('contact.contact');

        } else {

            return redirect()->route('login')->with('You are not allowed to access');

        }

    }
}
