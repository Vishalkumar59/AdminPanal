<?php

namespace App\Http\Controllers;
use Auth;

use Illuminate\Http\Request;
use App\Models\User;
use Hash;
use Session;
use Carbon\Carbon;


class CustomAuthController extends Controller
{
    public function index()
    {
        $data = User::orderBy('last_seen', 'DESC')->first();
     
        return view('auth.login', compact('data'));

    }  

    public function dashboard()
    {
        if (Auth::check()) {

            return view('dashboard');

        } else {

            return redirect()->route('login')->with('You are not allowed to access');

        }
    } 
    public function customLogin(Request $request)
    {
       
        $request->validate([

            'email' => 'required',
            'password' => 'required',

        ]);
   
        $credentials = $request->only('email', 'password');

        if (Auth::attempt($credentials)) {

            return redirect()->route('dashboard')->withSuccess('Signed in');
        }
  
        return redirect("login")->with( 'message','Login details are not valid');

    }

    public function registration()
    {
        return view('auth.registration');

    }

    public function customRegistration(Request $request)
    {  
        $request->validate([

            'name' => 'required',
            'email' => 'required|email|unique:users',
            'password' => 'required|min:6',

        ]);
           
        $data = User::create([

            'name' => $request->name,
            'email' => $request->email,
            'password' => Hash::make($request->password,),

        ]);
         
        return redirect("login")->with('message', 'You Are Register Successfully ');

    }

    public function signOut() 
    {
        if (Auth::check()) {

            User::where('id', Auth::user()->id)->update([

            'last_seen' => now()->format("Y-m-d H:i:s")

            ]);

            Session::flush();
            Auth::logout();
        
            return redirect('login');

        } else {

            return redirect()->route('login')->with('You are not allowed to access');

        }
    }   
}
