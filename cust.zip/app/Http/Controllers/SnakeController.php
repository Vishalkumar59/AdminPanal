<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;

class SnakeController extends Controller
{
    public function index(){
        return view('snake.index');
    }
    public function preloader(Request $request){
         $url = "/index";
    // return view('preloader', compact('url'));
        return view('preloader');
    }
}
